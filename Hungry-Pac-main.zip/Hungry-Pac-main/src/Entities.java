import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Entity Class
 * @version 1.0
 * @author Group Juan
 */
abstract public class Entities {
    /*
     * - Game Frame Object variable and call in constructor - String direction for
     * NPC's - speed of NPC's int - Rectangle object called solidArea that takes a
     * new rectangle which is default to a set of values (0,0,48,48) can be changed.
     * This is to set the dimensions. - Get player/NPC image method to return image
     * - Set up (get image from a file)
     */

    protected int[] colour;
    protected int positionX;
    protected String characterName;
    protected int speed;
    protected String direction;
    protected int positionY;
    protected boolean characterIsDead;
    protected boolean isVisible;

    protected BufferedImage up1, up2, down1, down2, left1, left2, right1, right2;

    protected Rectangle solidArea = new Rectangle(0, 0, 48, 48);
    protected int characterWidth;
    protected int characterHeight;

    // Game Frame gp; (need to implement Game Frame, call in constructor as well!)

    public Entities() {

    }

    public Entities(int colour[], String name, int positionX, int positionY) {
        this.characterName = name;
        this.positionX = positionX;
        this.positionY = positionY;

        isVisible = true;
        characterIsDead = false;

        getImage();
    }

    public void objectDies() {

    }

    public void collisionDetection() {

    }

    public void movementDirection() {

    }

    public void getBoundary() {

    }

    public void isVisible() {

    }

    public void getImage() {

        /*
         * return all BufferedImages movement E.g. up1 =
         * setupImage("/packagename/imagename");
         */
    }

    // Will be returning a BufferedImage.
    private void setupImage(String imagePath) {

        /*
         * UtilityTool uTool = new UtilityTool(); BufferedImage image = null;
         *
         * try { image = ImageIO.read(getClass().getResourceAsStream(imagePath +
         * ".png")); image =
         * uTool.scaleImage(image,GameFrameTileSize,GameFrameTileSize); } catch
         * (IOException e) { e.printStackTrace(); }
         *
         * return image;
         *
         */

    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public int getPositionX() {
        return positionX;
    }

    public void setPositionX(int positionX) {
        this.positionX = positionX;
    }

    public String getCharacterName() {
        return characterName;
    }

    public void setCharName(String charName) {
        this.characterName = charName;
    }

    public int getPositionY() {
        return positionY;
    }

    public void setPositionY(int positionY) {
        this.positionY = positionY;
    }

    public boolean isCharacterIsDead() {
        return characterIsDead;
    }

    public void setCharacterIsDead(boolean characterIsDead) {
        this.characterIsDead = characterIsDead;
    }

    public void setVisible(boolean visible) {
        isVisible = visible;
    }

    public int getCharacterWidth() {
        return characterWidth;
    }

    public void setCharacterWidth(int characterWidth) {
        this.characterWidth = characterWidth;
    }

    public int getCharacterHeight() {
        return characterHeight;
    }

    public void setCharacterHeight(int characterHeight) {
        this.characterHeight = characterHeight;
    }

}
