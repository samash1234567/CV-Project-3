import java.util.Scanner;

/**
 * User Class
 * @version 1.0
 * @author Group Juan
 */
public class User {
    Scanner fileScanner;
    String filePath;
    String userName;
    int levelUnlocked;

    public void LoadFile(String file){

    }

    public String getFilePath(){
        return filePath;
    }

    public int getLevelUnlocked() {
        return levelUnlocked;
    }

    public void setLevelUnlocked(int levelUnlocked) {
        this.levelUnlocked = levelUnlocked;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void saveGame(){

    }
}
