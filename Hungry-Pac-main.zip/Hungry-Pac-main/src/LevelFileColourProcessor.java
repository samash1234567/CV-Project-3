import java.io.FileNotFoundException;
import java.util.ArrayList;

public class LevelFileColourProcessor {
    ArrayList<ArrayList<Tile>> gameGrid;
    private int nowLevel;
    private TileType tileType;
    private int row;
    private int column;
    private TxtFileProcessor Level1FileTileColours;
    private TxtFileProcessor Level2FileTileColours;

    public LevelFileColourProcessor(ArrayList<ArrayList<Tile>> gameGrid, TileType tileType, int nowLevel, int row, int column) {
        this.gameGrid = gameGrid;
        this.tileType = tileType;
        this.nowLevel = nowLevel;
        this.row = row;
        this.column = column;
    }

    public void processTileColours() throws FileNotFoundException {
        Level1FileTileColours = new TxtFileProcessor("resources/Level1FileTileColours.txt");
        Level2FileTileColours = new TxtFileProcessor("resources/Level2FileTileColours.txt");
        ArrayList<String> fileContents;
        if(nowLevel == 1){
            fileContents = Level1FileTileColours.readFromFile();
        }
        else if(nowLevel == 2){
            fileContents = Level2FileTileColours.readFromFile();
        }
        else if(nowLevel == 3){
            fileContents = Level1FileTileColours.readFromFile();
        }
        else{
            fileContents = null;
        }
        for(int i = 0; i < row; i++){
            gameGrid.add(new ArrayList<Tile>());
            String[] res2 = fileContents.get(i).split(" ");
            for(int j = 0; j < column; j++){
                gameGrid.get(i).add(tileType.getTile(res2[j]));
            }
        }
    }

    public ArrayList<ArrayList<Tile>> getGameGrid() {
        return this.gameGrid;
    }
}
