import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class SaveGameFileHandle {
    ArrayList<Character> characters;
    ArrayList<Item> items;
    Player player;
    String positionsOnTiles[][] = new String[8][8];
    int score;
    private static int nowLevel = 1;
    public SaveGameFileHandle(Board currentBoard, ArrayList<Item> items, ArrayList<Character> characters, Player player, int score) {

        try {
            this.items = items;
            this.characters = characters;
            this.player = player;
            this.score = score;
            FileWriter playerFile = new FileWriter("resources/" + "/" + player.getName() + ".txt");
            playerFile.write(player.getName() + "\n");
            playerFile.write(nowLevel + "\n");
            playerFile.write(score + "\n");
            playerFile.write(currentBoard.getTime() + "\n");
            playerFile.close();

            FileWriter playerFilePositions = new FileWriter("resources/" + "/" + GameFrame.getPlayer().getName() + "Positions" + ".txt");
            savePositions();
            playerFilePositions.write(positionsOnTiles[0][0] + ";" + positionsOnTiles[1][0] + ";" + positionsOnTiles[2][0] + ";" + positionsOnTiles[3][0] + ";" + positionsOnTiles[4][0] + ";" + positionsOnTiles[5][0] + ";" + positionsOnTiles[6][0] + ";" + positionsOnTiles[7][0] + "\n");
            playerFilePositions.write(positionsOnTiles[0][1] + ";" + positionsOnTiles[1][1] + ";" + positionsOnTiles[2][1] + ";" + positionsOnTiles[3][1] + ";" + positionsOnTiles[4][1] + ";" + positionsOnTiles[5][1] + ";" + positionsOnTiles[6][1] + ";" + positionsOnTiles[7][1] + "\n");
            playerFilePositions.write(positionsOnTiles[0][2] + ";" + positionsOnTiles[1][2] + ";" + positionsOnTiles[2][2] + ";" + positionsOnTiles[3][2] + ";" + positionsOnTiles[4][2] + ";" + positionsOnTiles[5][2] + ";" + positionsOnTiles[6][2] + ";" + positionsOnTiles[7][2] + "\n");
            playerFilePositions.write(positionsOnTiles[0][3] + ";" + positionsOnTiles[1][3] + ";" + positionsOnTiles[2][3] + ";" + positionsOnTiles[3][3] + ";" + positionsOnTiles[4][3] + ";" + positionsOnTiles[5][3] + ";" + positionsOnTiles[6][3] + ";" + positionsOnTiles[7][3] + "\n");
            playerFilePositions.write(positionsOnTiles[0][4] + ";" + positionsOnTiles[1][4] + ";" + positionsOnTiles[2][4] + ";" + positionsOnTiles[3][4] + ";" + positionsOnTiles[4][4] + ";" + positionsOnTiles[5][4] + ";" + positionsOnTiles[6][4] + ";" + positionsOnTiles[7][4] + "\n");
            playerFilePositions.write(positionsOnTiles[0][5] + ";" + positionsOnTiles[1][5] + ";" + positionsOnTiles[2][5] + ";" + positionsOnTiles[3][5] + ";" + positionsOnTiles[4][5] + ";" + positionsOnTiles[5][5] + ";" + positionsOnTiles[6][5] + ";" + positionsOnTiles[7][5] + "\n");
            playerFilePositions.write(positionsOnTiles[0][6] + ";" + positionsOnTiles[1][6] + ";" + positionsOnTiles[2][6] + ";" + positionsOnTiles[3][6] + ";" + positionsOnTiles[4][6] + ";" + positionsOnTiles[5][6] + ";" + positionsOnTiles[6][6] + ";" + positionsOnTiles[7][6] + "\n");
            playerFilePositions.write(positionsOnTiles[0][7] + ";" + positionsOnTiles[1][7] + ";" + positionsOnTiles[2][7] + ";" + positionsOnTiles[3][7] + ";" + positionsOnTiles[4][7] + ";" + positionsOnTiles[5][7] + ";" + positionsOnTiles[6][7] + ";" + positionsOnTiles[7][7] + "\n");
            playerFilePositions.close();
        } catch (IOException e) {
            System.out.println("Failed to save file");
            e.printStackTrace();
        }
    }

    private void savePositions() {
        for (int y = 0; y < 8; y++) {
        for(int x = 0; x < 8; x++) {
                positionsOnTiles[x][y] = "NULL";
            }
        }
        for(int i = 0; i < characters.size(); i++) {
            Character tempCharacter = characters.get(i);
            int tempX = (int) (tempCharacter.getPos_x());
            int tempY = (int) (tempCharacter.getPos_y());
            positionsOnTiles[tempY][tempX] = tempCharacter.getName();
        }
        for(int i = 0; i < items.size(); i++) {
            Item tempItem = items.get(i);
            int tempX = (int) (tempItem.pos.getX());
            int tempY = (int) (tempItem.pos.getY());
            positionsOnTiles[tempY][tempX] = tempItem.getItemType();
        }
        int tempXPl = (int) (player.getPos_x());
        int tempYPl = (int) (player.getPos_y());
        positionsOnTiles[tempYPl][tempXPl] = player.getName();
    }
}
