import javafx.scene.image.Image;

/**
 * Tile Class
 * @version 1.0
 * @author Group Juan
 */
public class Tile {
    private Tile tileOn;
    private boolean CanMove;
    private TileType tileType;
    private Image image;

    /**
     * Create a new tile.
     * @param tileType Get the tiles type of the level
     */
    public Tile(TileType tileType){
        this.tileType = tileType;
    }

    public TileType getTileType() {
        return tileType;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public Tile(Image image){
        this.image = image;
    }

    public boolean canMove(){
        return CanMove;
    }

    public void placeCharacter(){

    }

    @Override
    public String toString(){
        StringBuilder res = new StringBuilder();
        res.append(image.getUrl());
        return res.toString();
    }
}
