import javafx.scene.image.Image;

public class Door extends Item{
    public boolean state;

    public Door(Image image, int x, int y) {
        super(image, new Position(x, y), "Door");
        score = 0;
    }

    public boolean getState(){
        return state;
    }

    public void setState(boolean state){
        this.state = state;
    }

    public void openDoor(){
    	this.state = true;
    }
}
