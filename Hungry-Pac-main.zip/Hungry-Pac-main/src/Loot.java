/**
 * Loot Class
 * @version 1.0
 * @author Group Juan
 */
public class Loot extends Item{
	private int value;
	private String name;

    /**
     * Set the loot gained by the player
     * @param val Value to be gained.
     * @param typeName Type of the name of loot.
     */
	public Loot(int val, String typeName) {
		setValue(val);
		setName(typeName);
	}
	
	public void setValue(int val) {
		value = val;
	}
	
	public void setName(String typeName) {
		name = typeName;
	}
	
	public int getValue() {
		return value;
	}
	
	public String getName() {
		return name;
	}
	
	
}
