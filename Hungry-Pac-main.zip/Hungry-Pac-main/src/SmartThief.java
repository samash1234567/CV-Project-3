import javafx.scene.image.Image;

import java.util.ArrayList;

/**
 * Smart Thief Class
 * @version 1.0
 * @author Group Juan
 */
public class SmartThief extends NPC{

    /**
     * Create a new NPC Smart Thief
     * @param colour Colour of the smart thief
     * @param entity Type of entity
     * @param entitySpeed Speed of the entity
     * @param objectName Object name of the entity
     * @param x Position on the board
     * @param y Position on the board
     */
    public SmartThief(Image colour, String entity, float entitySpeed, String objectName, int x, int y){
        super(entity, entitySpeed, objectName, x, y);
        this.colour = colour;
    }

    public void moveRules(){

    }
}
