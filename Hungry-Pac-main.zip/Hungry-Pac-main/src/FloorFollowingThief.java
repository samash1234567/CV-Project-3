import javafx.scene.image.Image;

import java.util.ArrayList;

public class FloorFollowingThief extends NPC{
	public Tile tileColour;

    /**
     * Create a new floor following thief
     * @param entity FloorFollowingThief Entity
     * @param entitySpeed Speed of the thief
     * @param objectName Floorfollowingthief
     * @param x Position on the board.
     * @param y Position on the board.
     */
    public FloorFollowingThief(String entity, float entitySpeed, String objectName, int x, int y) {
        super(entity, entitySpeed, objectName, x, y);
    }

    /**
     * Create a new FloorFollowingThief.
     *
     * @param colour Colour of the thief
     * @param entity FloorFollowingThief Entity
     * @param entitySpeed Speed of the thief
     * @param objectName Floorfollowingthief
     * @param x Position on the board.
     * @param y Position on the board.
     */
    public FloorFollowingThief(Tile tileColour, Image colour, String entity, float entitySpeed, String objectName, int x, int y){
        super(entity, entitySpeed, objectName, x, y);
        this.tileColour = tileColour;
        this.colour = colour;
    }
    
    public FloorFollowingThief(Image colour, String entity, float entitySpeed, String objectName, int x, int y){
        super(entity, entitySpeed, objectName, x, y);
        this.colour = colour;
    }
    
    public Tile getColour() {
    	return tileColour;
    }

    public void moveRules(){

    }
}
