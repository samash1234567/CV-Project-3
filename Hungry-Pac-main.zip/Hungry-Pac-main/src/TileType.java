import javafx.scene.image.Image;

import java.util.HashMap;
import java.util.Map;

/**
 * TileType Class
 * @version 1.0
 * @author Group Juan
 */
public class TileType {
    Image tileColor;
    Map<String, Tile> tileMap = new HashMap<>();

    /**
     * Create a new tile type.
     * @param tileColor Set the tile color for the tiles
     */
    public TileType(Image tileColor){
        this.tileColor = tileColor;
    }

    public TileType(){}

    private Tile loadTile(Image tileColor){
        this.tileColor = tileColor;
        return null;
    }

    /**
     * Add the tile onto the board and returns nothing. If it does not contain the tile already it will add it.
     * @param tileName Specify the tiles name to be added
     * @param tileColor Specify the tiles color to be added
     */
    public void addTile(String tileName, Image tileColor){
        if(!tileMap.containsKey(tileName)){
            tileMap.put(tileName, new Tile(tileColor));
        }
    }

    public Tile getTile(String tileName){
        return tileMap.get(tileName);
    }

    private void checkTile(String[] tileColor){

    }

    @Override
    public String toString(){
        StringBuilder res = new StringBuilder();
        for(String k: tileMap.keySet()){
            Tile tile = tileMap.get(k);
            res.append(k + ": " + tile.getImage().toString() + " ");
        }
        return res.toString();
    }
}
