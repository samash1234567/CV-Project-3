public class Doors extends Items {
	private boolean state; // false = closed, true = open

	public Doors() {
		setState(false);
		setSkin("Items/door.png");
	}

	public void setState(boolean stateOfDoor) {
		state = stateOfDoor;
	}
	
	public void setSkin(String skin) {
		this.skin = skin;
	}
	
	public String getSkin() {
		return skin;
	}

	public void openDoor() {
		setState(true);
	}

	public boolean getState() {
		return state;
	}
}
