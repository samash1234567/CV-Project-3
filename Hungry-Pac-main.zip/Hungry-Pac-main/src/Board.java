import javafx.animation.Timeline;
import javafx.geometry.Insets;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;

import java.awt.*;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Board {
    Tile[] tiles;
    public BorderPane root;
    final int timeVal = 60;
    private int time = timeVal;
    int nowScore = 0;
    // Timeline which will cause tick method to be called periodically.
    public Timeline tickTimeline;
    // X and Y coordinate of player on the grid.
    private Player player;
    public boolean continue_is = false;
    Label count1;
    Label count2;
    Canvas canvas;
    // Loaded images

    Graphics2D g2;
    public Image blueTile;
    public Image cyanTile;
    public Image greenTile;
    public Image magentaTile;
    public Image redTile;
    public Image yellowTile;
    // Player
    public Image player1;
    public Image player2;
    public Image player3;
    public Image player4;
    public Image player5;
    // items
    Image doorImage;
    Image gate1Image; //closed gate
    Image gate2Image; //open gate
    Image leverOneImage;
    Image leverTwoImage;
    Image goldCoin;
    Image ruby;
    Image silverCoin;
    Image diamond;
    Image clock;

    // characters
    Image smartThief;
    Image floorFollowingThief;
    Image flyingAssassin;
    // The width and height (in pixels) of each cell that makes up the game.
    protected static final int GRID_CELL_WIDTH = 50;//was 25
    protected static final int GRID_CELL_HEIGHT = 50;
    HBox toolbar;
    Button startTickTimelineButton;
    Button stopTickTimelineButton;
    Button saveGameButton;
    Button loadGameButton;

    // The width of the grid in number of cells.
    protected static final int GRID_WIDTH = 32; //was 32
    private ArrayList<ArrayList<Tile>> gameGrid = new ArrayList<>();
    private ArrayList<Item> items = new ArrayList<>();
    private ArrayList<Character> characters = new ArrayList<>();
    private TileType tileType;

    public float getPlayerX() {
        return player.pos_x;
    }

    public void setPlayerX(float playerX) {
        player.pos_x = playerX;
    }

    public float getPlayerY() {
        return player.pos_y;
    }

    public void setPlayerY(float playerY) {
        player.pos_y = playerY;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }
    public void setScore(int score) {
        this.nowScore = score;
    }
    public int getScore() {
        return nowScore;
    }

    public Board(Item[] items, Character[] characters, Tile[] tiles) {
        this.tiles = tiles;
    }

    public void setPlayer(Player player) {
        this.player = player;
        player1 = new Image("file:resources/Player-1.png");
        player2 = new Image("file:resources/Player-2.png");
        player3 = new Image("file:resources/Player-3.png");
        player4 = new Image("file:resources/Player-4.png");
        player5 = new Image("file:resources/Player-5.png");
        player.addState(player1);
        player.addState(player2);
        player.addState(player3);
        player.addState(player4);
        player.addState(player5);
        player.setStartImage(1);
    }

    public Board(Canvas canvas1, int canvas_width, int canvas_height) throws FileNotFoundException {
        blueTile = new Image("file:resources/blueTile.png");
        greenTile = new Image("file:resources/greenTile.png");
        cyanTile = new Image("file:resources/cyanTile.png");
        magentaTile = new Image("file:resources/magentaTile.png");
        redTile = new Image("file:resources/redTile.png");
        yellowTile = new Image("file:resources/yellowTile.png");

        doorImage = new Image("file:resources/door.png");
        gate1Image = new Image("file:resources/gateOne.png");
        gate2Image = new Image("file:resources/gateTwo.png");
        leverOneImage = new Image("file:resources/leverOne.png");
        leverTwoImage = new Image("file:resources/leverTwo.png");
        goldCoin = new Image("file:resources/goldCoin.png");
        ruby = new Image("file:resources/ruby.png");
        silverCoin = new Image("file:resources/silverCoin.png");
        diamond = new Image("file:resources/diamond.png");
        clock = new Image("file:resources/clockOne.png");

        floorFollowingThief = new Image("file:resources/floorFollowingThief.png");
        flyingAssassin = new Image("file:resources/flyingAssassin.png");
        smartThief = new Image("file:resources/smartThief.png");

        tileType = new TileType();
        tileType.addTile("B", blueTile);
        tileType.addTile("G", greenTile);
        tileType.addTile("M", magentaTile);
        tileType.addTile("R", redTile);
        tileType.addTile("Y", yellowTile);
        tileType.addTile("C", cyanTile);

        System.out.println(tileType);
        int row = canvas_width / 25;// change back to 25 for both
        int column = canvas_height / 25;
        System.out.println(row + " rows " + column + " columns");

        //Loads the level file stuff using method below in Board
        int nowLevel = GameFrame.getNowLevel();
        LevelFileColourProcessor levelColourProcessor = new LevelFileColourProcessor(gameGrid, tileType, nowLevel, row, column);
        levelColourProcessor.processTileColours();
        this.gameGrid = levelColourProcessor.getGameGrid();

        System.out.println(gameGrid);
        System.out.println(gameGrid.size());
        root = new BorderPane();

        // Create the canvas that we will draw on.
        // We store this as a gloabl variable so other methods can access it.
        canvas1 = canvas = new Canvas(canvas_width, canvas_height);
        root.setCenter(canvas);

        // Create a toolbar with some nice padding and spacing
        toolbar = new HBox();
        toolbar.setSpacing(10);
        toolbar.setPadding(new Insets(10, 10, 10, 10));
        root.setTop(toolbar);

        // Create the toolbar content
        Label label1 = new Label();
        label1.setFont(new Font("Times New Roman", 20));
        label1.setText("Remain Time");
        toolbar.getChildren().add(label1);

        count1 = new Label();
        count1.setMinSize(60, 10);
        count1.setFont(new Font("Times New Roman", 20));
        toolbar.getChildren().add(count1);
        count1.setStyle("-fx-background-color: #D1BA74;");
        count1.setText(time + " s");

        Label label2 = new Label();
        label2.setFont(new Font("Times New Roman", 20));
        label2.setText("Score");
        toolbar.getChildren().add(label2);

        count2 = new Label();
        count2.setMinSize(60, 10);
        count2.setFont(new Font("Times New Roman", 20));
        toolbar.getChildren().add(count2);
        count2.setStyle("-fx-background-color: #D1BA74;");
        count2.setText("" + nowScore);
        
        //Label label3
    }

    public Board(Canvas canvas1, int canvas_width, int canvas_height, Player p1) throws FileNotFoundException {
        this(canvas1, canvas_width, canvas_height);
        player = p1;
    }

    public Tile[] getTiles() {
        return tiles;
    }

    public void setTiles(Tile[] tiles) {
        this.tiles = tiles;
    }

    public void setItems(ArrayList<Item> items) {
        this.items = items;
    }

    public void setCharacters(ArrayList<Character> characters) {
        this.characters = characters;
    }

    public String getTile() {
        return "";
    }



    /**
     * Draw the game on the canvas.
     */
    public void drawGame() {
        // Get the Graphic Context of the canvas. This is what we draw on.
        GraphicsContext gc = canvas.getGraphicsContext2D();

        // Clear canvas
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

        for (int j = 0; j < gameGrid.size(); j++) {
            for (int i = 0; i < gameGrid.get(j).size(); i++) {
                gc.drawImage(gameGrid.get(i).get(j).getImage(), (j * 25), (i * 25),
                        (GRID_CELL_WIDTH / 2), (GRID_CELL_HEIGHT / 2));
            }
        }

        for (int i = 0; i < items.size(); i++) {
            Item item = items.get(i);
            gc.drawImage(item.image, item.pos.getY() * GRID_CELL_WIDTH, item.pos.getX() * GRID_CELL_HEIGHT);
        }

        for (int i = 0; i < characters.size(); i++) {
            Character character = characters.get(i);
            gc.drawImage(character.colour, character.pos_y * GRID_CELL_WIDTH, character.pos_x * GRID_CELL_HEIGHT);
        }

        // Draw player at current location
        if (continue_is) {
            gc.drawImage(player.nowImage, player.pos_y * GRID_CELL_WIDTH, player.pos_x * GRID_CELL_HEIGHT);
        }

        count1.setText(time + " s");
        count2.setText("" + nowScore);
    }

    public ArrayList<Item> getItems() {
        return items;
    }
    public ArrayList<Character> getCharacters() {
        return characters;
    }
    
    public ArrayList<ArrayList<Tile>> getBoardTiles() {
    	return gameGrid;
    }
}
