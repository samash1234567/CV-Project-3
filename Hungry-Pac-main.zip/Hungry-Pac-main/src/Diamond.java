import javafx.scene.image.Image;

public class Diamond extends Item{
    public Diamond(Image image, int x, int y){
        super(image, new Position(x, y), "Diamond");
        score = 30;
    }
}
