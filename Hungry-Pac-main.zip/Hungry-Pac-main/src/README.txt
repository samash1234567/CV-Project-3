Instructions to run the game:
The whole game will run from running the main class.
once the Game window has popped up:
to start the game for the very first time, press start ticks and the game will begin.
press stop ticks to pause the game at any point
or press save game to save the current state of the game.
You can also load a previous game using the load game button.

In game instructions:
Aim of the game is to collect all the loot and levers before the thieves and to not get
killed by the flying thief. Once everything required is collected, head to the door 
to progress to the next level. The more loot collected, the higher the score!