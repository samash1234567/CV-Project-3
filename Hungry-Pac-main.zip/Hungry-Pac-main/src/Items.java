/**
 * Items Class
 * @version 1.0
 * @author Group Juan
 */
abstract class Items {
	private boolean readyToDespawn;
	private int position;
	private String itemType;
	protected String skin;
	// skin attribute

	public String getItemType() {
		return itemType;
	}

	public void applyItem() {
		// applies item to player/game
	}

	public boolean getReadyToDespawn() {
		return readyToDespawn;
	}

	public void setitemPos(int xy) {
		// sets item to position on board/assigns to tile
	}

	public void lockTile() {
		// sets tile to locked
	}

}
