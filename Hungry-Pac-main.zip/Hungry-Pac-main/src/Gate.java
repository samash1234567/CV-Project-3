import javafx.scene.image.Image;

/**
 * Gate Class
 * @version 1.0
 * @author Group Juan
 */
public class Gate extends Item{
	private int[] colour;
	private boolean state; //false = closed, true = open

    /**
     * Create a new gate.
     * @param image Process the image
     * @param x Position on the board
     * @param y Position on the board
     * @param state The state (open/closed)
     */
	public Gate(Image image, int x, int y, boolean state){
        super(image, new Position(x, y), "gateOne");
        setState(state);
    }
	
	//public void createLinkedGate() {
	//	new Lever(this, colour);
	//}
	
	public boolean getState() {
		return state;
	}
	
	public void setState(boolean gateState) {
		state = gateState;
	}
	
}
