import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.http.HttpClient;

import java.io.FileNotFoundException;

/**
 * Sample application that demonstrates the use of JavaFX Canvas for a Game.
 * This class is intentionally not structured very well. This is just a starting point to show
 * how to draw an image on a canvas, respond to arrow key presses, use a tick method that is
 * called periodically, and use drag and drop.
 * <p>
 * Do not build the whole application in one file. This file should probably remain very small.
 *
 * @author Liam O'Reilly
 */
public class Main extends Application {
	private static final String URL = "http://cswebcat.swansea.ac.uk/puzzle";
    // The dimensions of the window
    private static final int WINDOW_WIDTH = 800;
    private static final int WINDOW_HEIGHT = 500;

	// The dimensions of the canvas
	private static final int CANVAS_WIDTH = 400;
	private static final int CANVAS_HEIGHT = 400;
	
	// The canvas in the GUI. This needs to be a global variable
	// (in this setup) as we need to access it in different methods.
	// We could use FXML to place code in the controller instead.
	private Canvas canvas;
	private GameFrame gameFrame;
	
	/**
	 * Setup the new application.
	 * @param primaryStage The stage that is to be used for the application.
	 */
	public void start(Stage primaryStage) throws FileNotFoundException {

		// Build the GUI 
		Pane root = buildGUI();
		
		// Create a scene from the GUI
		Scene scene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
				
		// Register an event handler for key presses.
		// This causes the processKeyEvent method to be called each time a key is pressed.
		scene.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
			try {
				processKeyEvent(event);
			} catch (FileNotFoundException e) {
				throw new RuntimeException(e);
			}
		});
				
		// Register a tick method to be called periodically.
		// Make a new timeline with one keyframe that triggers the tick method every half a second.
		gameFrame.board.tickTimeline = new Timeline(new KeyFrame(Duration.millis(500), event -> tick()));
		 // Loop the timeline forever
		gameFrame.board.tickTimeline.setCycleCount(Animation.INDEFINITE);
		// We start the timeline upon a button press.
		
		// Display the scene on the stage
		gameFrame.board.drawGame();
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	/**
	 * Process a key event due to a key being pressed, e.g., to move the player.
	 * @param event The key event that was pressed.
	 */
	public void processKeyEvent(KeyEvent event) throws FileNotFoundException {
		// We change the behaviour depending on the actual key that was pressed.
		System.out.println(event.getCode());
		gameFrame.processKeyEvent(event.getCode());
		
		// Consume the event. This means we mark it as dealt with. This stops other GUI nodes (buttons etc) responding to it.
		event.consume();
	}
	
	/**
	 * This method is called periodically by the tick timeline
	 * and would for, example move, perform logic in the game,
	 * this might cause the bad guys to move (by e.g., looping
	 * over them all and calling their own tick method). 
	 */
	public void tick() {
		// Here we move the player right one cell and teleport
		// them back to the left side when they reach the right side.
		gameFrame.tick();
		// We then redraw the whole canvas.
		gameFrame.board.drawGame();
	}
	
	/**
	 * Create the GUI.
	 * @return The panel that contains the created GUI.
	 */
	private Pane buildGUI() throws FileNotFoundException {
		// Create top-level panel that will hold all GUI nodes.
		gameFrame = new GameFrame(canvas, CANVAS_WIDTH, CANVAS_HEIGHT);
		return gameFrame.board.root;
	}
	        	
	public static void main(String[] args) {
		String s = "ABCD";
        System.out.println(messageOftehDay(s));
        /*
        this is an way to get hte url and connect an api
         */
        URL oracle;
		try {
			oracle = new URL(URL);
			URLConnection yc = oracle.openConnection();
	        BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
	        String inputLine;
	        inputLine = in.readLine();
	        char[] arr = inputLine.toCharArray();
	        String urlString = "http://cswebcat.swansea.ac.uk/message?solution=9BCYCS-230";
	        URL url = new URL(urlString);
	        URLConnection conn = url.openConnection();
	        InputStream is = conn.getInputStream();
		} catch (MalformedURLException e) {
		} catch (IOException e) {}
		launch(args);
	}
	
	public static String messageOftehDay(String sr) {
        StringBuilder builderFinal = new StringBuilder();
        String encrypted = "";
        int n = 2;
        for (int i = 0; i < sr.length(); i++) {
            char currentCharcter = sr.charAt(i);
            if (i % n == 0) {
                //move backwards
                if (currentCharcter == 'A' || currentCharcter >= 'Z') {
                  currentCharcter -= (i - 1);

                } else {
                    currentCharcter -= n;
                    encrypted += currentCharcter;

                    i++;

                }
            } else {
                // move forward
                if (currentCharcter + (i + 1) <= 'Z') {
                    currentCharcter += (n + 1);
                    encrypted += currentCharcter;


                }
                else if (currentCharcter + (i +1) > 90){
                    currentCharcter += (i + 1);
                    encrypted += currentCharcter;
                    int change = currentCharcter - 64 + 90;
                }

            }

        }
      //  builderFinal.append(encrypted);
        int count = sr.length();

        return  encrypted;
    }
}
