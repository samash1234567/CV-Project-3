import javafx.scene.image.Image;

/**
 * Silver Class
 * @version 1.0
 * @author Group Juan
 */
public class SilverCoin extends Item{

    /**
     * Create a new silver coin
     * @param image Process the image of the coin
     * @param x Position on the board
     * @param y Position on the board
     */
    public SilverCoin(Image image, int x, int y){
        super(image, new Position(x, y), "SilverCoin");
        score = 10;
    }
}
