import javafx.scene.image.Image;

/**
 * Lever Class
 * @version 1.0
 * @author Group Juan
 */
public class Lever extends Item {

	private Gate gateLink;

    /**
     * Create a new lever.
     * @param image Process the image
     * @param x Position on the board
     * @param y Position on the board
     */
	public Lever(Image image, int x, int y){
        super(image, new Position(x, y), "Lever");
        score = 0;
	}
	
}
