import javafx.scene.image.Image;

import java.util.ArrayList;

/**
 * Player Class
 * @version 1.0
 * @author Group Juan
 */
public class Player extends Character{
    private static String userName;
    private float playerSpeed;
    private boolean isMoving;
    Image nowImage;
    ArrayList<Image> images = new ArrayList<>();
    int state = 1;  // 5 states: 1 2 3 4 5

    /**
     * Create a new player.
     * @param userName Username of the player
     * @param objectName Objectname is the player
     * @param x Position on the board
     * @param y Position on the board
     */
    public Player(String userName, String objectName, int x, int y) {
        super(objectName, x, y);
        this.userName = userName;
    }

    public void setStartImage(int index){
        nowImage = images.get(index-1);
    }

    public Position getPos(){
        return new Position(pos_x, pos_y);
    }

    public void addState(Image image){
        images.add(image);
    }

    public void setPos(Position pos){
        pos_x = pos.getX();
        pos_y = pos.getY();
    }

    public String getName() {
        return userName;
    }
}
