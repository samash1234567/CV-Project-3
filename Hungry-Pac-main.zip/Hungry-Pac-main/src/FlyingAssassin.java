import javafx.scene.image.Image;
import java.util.Random;

/**
 * Flying Assasin Class that extends the NPC class.
 * @version 1.0
 * @author Group Juan
 */
public class FlyingAssassin extends NPC{
    String direction;

    /**
     * Create a new Flying Assassin.
     * @param image Process the image of the Flying Assassin
     * @param objectName Object name is the Flying Assassin
     * @param x Position on the board
     * @param y Position on the board
     */
    public FlyingAssassin(Image image, String objectName, int x, int y) {
        super(objectName, x, y);
        this.colour = image;
        direction = setDirection();
    }

    public void moveRules(){

    }

    /**
     * Set the Direction of the Flying Assassin.
     * @return the different directions to randomly go in.
     */
    public String setDirection() {
    	Random rand = new Random();
    	String[] directions = {"UP", "DOWN", "LEFT", "RIGHT"};
    	return (directions[rand.nextInt(directions.length)]);
    }

    public Character kill(){
        return null;
    }
}
