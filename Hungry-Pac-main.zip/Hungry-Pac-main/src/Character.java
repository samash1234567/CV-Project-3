import javafx.scene.image.Image;

/**
 * Character Class
 * @version 1.0
 * @author Group Juan
 */
public class Character {
    protected float pos_x;
    protected float pos_y;
    protected String name;
    protected boolean isDead;
    Image colour;

    /**
     * Creating a character with the colour.
     * @param colour Colour of the character
     * @param objectName Name of the Character
     * @param x Position on the board
     * @param y Position on the board
     */
    public Character(Image colour, String objectName, int x, int y){
        name = objectName;
        pos_x = x;
        pos_y = y;
        this.colour = colour;
    }

    /**
     * Creating a character.
     * @param objectName Name of the character
     * @param x Position on the board
     * @param y Position on the board
     */
    public Character(String objectName, int x, int y){
        name = objectName;
        pos_x = x;
        pos_y = y;
    }

    public void collisionDetection(){

    }

    public void objectDies(){

    }

    public void movementDirection(){

    }

    public void move(){

    }

    public float getPos_x(){
        return pos_x;
    }
    public float getPos_y(){
        return pos_y;
    }

    public String getName() {
        return name;
    }
}
