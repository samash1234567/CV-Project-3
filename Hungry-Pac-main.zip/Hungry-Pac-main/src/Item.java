import javafx.scene.image.Image;

import java.util.ArrayList;

/**
 * Item Class
 * @version 1.0
 * @author Group Juan
 */
public class Item {
    protected boolean readyToDespawn;
    protected Position pos;
    protected String skin;
    protected Image image;
    int score = 10;
    public Item(){}

    public Item(Position pos){
        this.pos = pos;
    }

    /**
     * Create a new Item.
     * @param image Process the image
     * @param pos Process the position on the board
     */
    public Item(Image image, Position pos, String skin){
        this.image = image;
        this.pos = pos;
        this.skin = skin;
    }

    public String getItemType(){
        return skin;
    }

    public ArrayList<Character> applyToCharacters(ArrayList<Character> Characters){
        return null;
    }

    public boolean isReadyToDespawn(){
        return readyToDespawn;
    }

    public void setItemVector(Position pos){
        this.pos = pos;
    }

    public void lockTile(boolean locked){

    }
}
