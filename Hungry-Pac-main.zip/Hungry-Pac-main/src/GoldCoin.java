import javafx.scene.image.Image;

/**
 * Gold coin Class
 * @version 1.0
 * @author Group Juan
 */
public class GoldCoin extends Item{
    int score = 20;

    /**
     * Create a new gold coin.
     * @param image Process the gold coin image
     * @param x Position on the board
     * @param y Position on the board
     */
    public GoldCoin(Image image, int x, int y){
        super(image, new Position(x, y), "GoldCoin");
        score = 20;
    }
}
