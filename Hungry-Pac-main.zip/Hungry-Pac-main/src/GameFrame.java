import javafx.scene.canvas.Canvas;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;

/**
 * Game Frame Class
 * @version 1.0
 * @author Group Juan
 */
public class GameFrame {
    int runningTicket;

    int width;
    int height;
    static int score;
    int time;
    int collectableItems = 0;
    ArrayList<Character> characters;

    public int commandNum = 0;
    ArrayList<Item> items;
    Board board;
    static Player player;
    // player's speed
    private float playerSpeed = 1;
    private int circle = 1;
    private static int nowLevel = 1;

    /**
     * Create a Game Frame.
     * @param items List all the items in an array
     * @param characters List all the characters in an array
     * @param tiles List all the possible tiles in an array.
     *  Create a board full of items, characters, and tiles
     */
    public GameFrame(Item[] items, Character[] characters, Tile[] tiles){
        board = new Board(items, characters, tiles);
    }


    /**
     * Create a Game Frame.
     * @param canvas The canvas frame
     * @param w Width of the canvas
     * @param h Height of the canvas
     *
     * Set the states and ticks for the game.
     */
    public GameFrame(Canvas canvas, int w, int h) throws FileNotFoundException {
        board = new Board(canvas, w, h);
        width = w; //was *2
        height = h;
        //player = new Player("Alice", "001", 0, 0);
        // Tick Timeline buttons
        board.startTickTimelineButton = new Button("Start Level");
        board.stopTickTimelineButton = new Button("Stop Level");
        board.saveGameButton = new Button("Save Game");
        board.loadGameButton = new Button("Load Game");
        // We add all buttons at the same time to the timeline (we could have done this in two steps).
        board.toolbar.getChildren().addAll(board.startTickTimelineButton, board.stopTickTimelineButton, board.saveGameButton, board.loadGameButton);
        // Stop button is disabled by default
        board.stopTickTimelineButton.setDisable(true);

        // Setup the behaviour of the buttons.
        board.startTickTimelineButton.setOnAction(e -> {
        // Start the tick timeline and enable/disable buttons as appropriate.
            board.setScore(0);
        board.startTickTimelineButton.setDisable(true);
        board.tickTimeline.play();
        board.stopTickTimelineButton.setDisable(false);
        board.continue_is = true;
        try {
        	startGame();
        } catch (FileNotFoundException e1) {
			System.out.println("Error: Couldn't find file");
		}
        });

        board.stopTickTimelineButton.setOnAction(e -> {
            // Stop the tick timeline and enable/disable buttons as appropriate.
            board.stopTickTimelineButton.setDisable(true);
            board.tickTimeline.stop();
            board.startTickTimelineButton.setDisable(false);
            board.continue_is = false;
        });
        
        board.saveGameButton.setOnAction(e -> {
            board.stopTickTimelineButton.setDisable(true);
            board.tickTimeline.stop();
            board.startTickTimelineButton.setDisable(false);
            new SaveGameFileHandle(board, items, characters, player, board.getScore());
        	board.continue_is = false;
        });

        board.loadGameButton.setOnAction(e -> {
            nowLevel = 3;
            board.stopTickTimelineButton.setDisable(true);
            board.startTickTimelineButton.setDisable(false);
            TxtFileProcessor PlayerFileDetails;
            try {
                PlayerFileDetails = new TxtFileProcessor("resources/Player.txt");
            } catch (FileNotFoundException ex) {
                throw new RuntimeException(ex);
            }
            ArrayList<String> processor = PlayerFileDetails.readFromFile();
            board.tickTimeline.play();
            board.continue_is = true;
            try {
                score = Integer.parseInt(processor.get(2));
                board.setScore(Integer.parseInt(processor.get(2)));
                startGame();
                board.setTime(Integer.parseInt(processor.get(3)));
            } catch (FileNotFoundException e1) {
                System.out.println("Error: Couldn't find file");
            }
        });
    }
    /*

    public void titleScreen() {
    	   	
        //Title Name:
    	//g2.setStyle(Color.BLACK);
        g2.fillRect(0,0,Main.CANVAS_WIDTH,Main.CANVAS_HEIGHT);
        
        
        g2.setFont(g2.getFont().deriveFont(96F));
        String text = "Hungry Pac";
        int x = getXCentered(text);
        int y = Main.CANVAS_WIDTH*3;

        //g2.setColor(Color.WHITE);
        g2.drawString(text,x,y);
		

        //MENU
        g2.setFont(g2.getFont().deriveFont(48F));
        text = "START GAME";
        x = getXCentered(text);
        y += Main.CANVAS_WIDTH*4;
        g2.drawString(text,x,y);

        if(commandNum == 0) {
            g2.drawString(">",x-Main.CANVAS_WIDTH,y);
        }


        g2.setFont(g2.getFont().deriveFont(48F));
        text = "LOAD GAME";
        x = getXCentered(text);
        y += Main.CANVAS_WIDTH;
        g2.drawString(text,x,y);

        if(commandNum == 0) {
            g2.drawString(">",x-Main.CANVAS_WIDTH,y);
        }


        g2.setFont(g2.getFont().deriveFont(48F));
        text = "QUIT";
        x = getXCentered(text);
        y += Main.CANVAS_WIDTH;
        g2.drawString(text,x,y);

        if(commandNum == 0) {
            g2.drawString(">",x-Main.CANVAS_WIDTH,y);
        }
        

    }
    
    public int getXCentered(String text) {
        int length = (int)g2.getFontMetrics().getStringBounds(text,g2).getWidth();
        int x = Main.CANVAS_WIDTH/2 - length/2;
        return x;
    }
    */

    public Board getBoard(){
        return board;
    }

    public static int getScore(){
        return score;
    }

    /**
     * Tick will not return anything but will set all the characters and items on the board with their movement.
     */
    public void tick(){
        /// Was used to test if the saving class works, it does. Game saves into 2 files every tick
        ///new SaveGameFileHandle(board, items, characters, player,score);
        if(board.continue_is){
            characters = board.getCharacters();
            int random_index = new Random().nextInt(4);
            ArrayList<Integer> temp_buffer = new ArrayList<>();
            for(Character character: characters){
                boolean ident1 = true;
                float new_x = character.pos_x;
                float new_y = character.pos_y;
                while(ident1) {
//                	if (character instanceof FloorFollowingThief) {
//                    	FloorFollowingThief floorFollowingThiefChar = (FloorFollowingThief) character;
//                    	Tile thiefsTile = floorFollowingThiefChar.getColour();
//                    	boolean lookingForNext = true;
//                		if (lookingForNext) {
//                			boolean moveRight = false;
//                			for (Tile tile: findCurrentTile(new_x, new_y + 1)) {
//                				if (tile.toString().equals(thiefsTile.toString())) {
//                					moveRight = true;
//                				}
//                			}
//                			boolean moveDown = false;
//                			if ((new_x + 1) <= (width / 50.0 -1)) {
//	                			for (Tile tile: findCurrentTile(new_x+1, new_y)) {
//	                				if (tile.toString().equals(thiefsTile.toString())) {
//	                					moveDown = true;
//	                				}
//	                			}
//                			}
//                			boolean moveUp = false;
//                			for (Tile tile: findCurrentTile(new_x - 1, new_y)) {
//                				if (tile.toString().equals(thiefsTile.toString())) {
//                					moveUp = true;
//                				}
//                			}
//                			if (!(checkMove(new_x, new_y+1, true)) && (new_y + 1) <= (width / 50.0 - 1) && moveRight) {
//                				System.out.println("right");
//                    			
//                    			if (moveRight) {
//	                    			new_y += 1;
//	                    			lookingForNext = false;
//                    			}
//                    		} else if (!(checkMove(new_x+1, new_y, true)) && (new_x + 1) <= (width / 50.0 -1) && moveDown) {
//                    			System.out.println("down");
//                    			
//                    			if (moveDown) {
//                    				new_x += 1;
//                    				lookingForNext = false;
//                    			}
//                    		} else if (!(checkMove(new_x-1, new_y, true)) && (new_x - 1) >= -1 && moveUp) {
//                    			System.out.println("up");
//                    			
//                    			if (moveUp) {
//	                    			new_x -= 1;
//	                    			lookingForNext = false;
//                    			}
//                    		} else if (!(checkMove(new_x, new_y-1, true)) && (new_y - 1) >= -1) {
//                    			System.out.println("left");
//                    			boolean moveLeft = false;
//                    			for (Tile tile: findCurrentTile(new_x, new_y - 1)) {
//                    				if (tile.toString().equals(thiefsTile.toString())) {
//                    					moveLeft = true;
//                    				}
//                    			}
//                    			if (moveLeft) {
//	                    			new_y -= 1;
//	                    			lookingForNext = false;
//                    			}
//                    		}
//                    		System.out.println("New Positions: " + character.name + " : "+ new_x  + ", "+ new_y);
//                    	}
                	if (character instanceof FloorFollowingThief || character instanceof SmartThief) {
                		if (random_index == 0) {
                            new_x += 1;
                        } else if (random_index == 1) {
                            new_x -= 1;
                        } else if (random_index == 2) {
                            new_y += 1;
                        } else if (random_index == 3) {
                            new_y -= 1;
                        }                		
                    } else if (character instanceof FlyingAssassin) {
                    	FlyingAssassin flyingAssassin =  (FlyingAssassin) character;
                    	if (flyingAssassin.direction == "UP") {
                            new_x += 1;
                        } else if (flyingAssassin.direction == "DOWN") {
                            new_x -= 1;
                        } else if (flyingAssassin.direction == "LEFT") {
                            new_y -= 1;
                        } else if (flyingAssassin.direction == "RIGHT") {
                            new_y += 1;
                        }
                    }
                	if (checkMove(new_x, new_y, true)) {
                		new_x = character.pos_x;
                		new_y = character.pos_y;
                	}
                    boolean ident2 = false;
                    if(new_x < 0 || new_x >= (width / 50.0 - 1 + 0.1) || new_y < 0 || new_y >= (width / 50.0 - 1 + 0.1)){
                        ident2 = true;
                        if (character instanceof FlyingAssassin) {
	                        FlyingAssassin flyingAssassin =  (FlyingAssassin) character;
	                    	switch (flyingAssassin.direction) {
	                    	case "UP":
	                    		flyingAssassin.direction = "DOWN";
	                    		break;
	                    	case "DOWN":
	                    		flyingAssassin.direction = "UP";
	                    		break;
	                    	case "LEFT":
	                    		flyingAssassin.direction = "RIGHT";
	                    		break;
	                    	case "RIGHT":
	                    		flyingAssassin.direction = "LEFT";
	                    		break;
	                    	}
                        }
                    }
                    if(!ident2){
                        ident1 = false;
                    }
                    if(!temp_buffer.contains(random_index)){
                        temp_buffer.add(random_index);
                    }
                    if(temp_buffer.size() == 4){
                        break;
                    }
                    random_index = new Random().nextInt(4);
                }
                if(!ident1) {
                    character.pos_x = new_x;
                    character.pos_y = new_y;
                    System.out.println(character.name + ": " + character.pos_x + " " + character.pos_y);
                }
            }
            if(circle < 2){
                circle += 1;
            }
            else{
                circle = 1;
                board.setTime(board.getTime() - 1);
                if(board.getTime() <= 0){
                    board.stopTickTimelineButton.setDisable(true);
                    board.tickTimeline.stop();
                    board.startTickTimelineButton.setDisable(false);
                    board.continue_is = false;
                    board.setTime(board.timeVal);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setContentText("Timeout!\nFailed!");
                    alert.show();
                }
            }
        }
        checkItemActivated();
    }

    public void addToScore(int addScore){
        score += addScore;
    }

    public int checkClocks(){
        return 0;
    }

    public int checkBombs(){
        return 0;
    }

    private void startGame() throws FileNotFoundException{
        LevelFilePositionProcessor levelProcessor = new LevelFilePositionProcessor(board, player, nowLevel);
        levelProcessor.loadPositions();
        this.board = levelProcessor.getBoard();
        this.player = levelProcessor.getPlayer();
        this.nowLevel = levelProcessor.getNowLevel();
        this.characters = levelProcessor.characters;
        this.items = levelProcessor.items;
        this.collectableItems = levelProcessor.collectableItems;
    }

    /**
     * Waiting for user input to move the player in a direction.
     * @param keyCode Key pressed
     */
    public void processKeyEvent(KeyCode keyCode) throws FileNotFoundException {
    	/*
        boolean stopMenu = false;
        if(stopMenu) {

           switch(keyCode) {

               case UP:
                   commandNum--;

                   if(commandNum < 0) {
                       commandNum = 2;
                   }
                   break;
               case DOWN:
                   commandNum++;
                   if(commandNum > 2) {
                       commandNum = 0;
                   }
                   break;
               case ENTER:
                   if(commandNum == 0) {
                       //start game
                    startGame();
                   }
                   if(commandNum == 1) {
                       //loading bit
                   }
                   if(commandNum == 2) {
                       //User has pressed exit
                       System.exit(0);
                   }
           }
           stopMenu = true;


        }*/

        boolean playerMoved = false;
        if(board.continue_is) {
            switch (keyCode) {
                case RIGHT:
                    // Right key was pressed. So move the player right by one cell.
                    if ((board.getPlayerY() + 1) >= (width / 50.0 -1 + 0.1) ||
                    		checkMove(board.getPlayerX(), board.getPlayerY() + 1, false)) {

                    } else {
                        int i = 1;
                    	ArrayList<Tile> currentTiles = findCurrentTile(board.getPlayerX(), board.getPlayerY());
                        while (((board.getPlayerY() + i) <= (width / 50.0 -1 + 0.1) && playerMoved == false)) {
                        	boolean playerCanMove = false;
                        	ArrayList<Tile> testTiles = findCurrentTile(board.getPlayerX(), board.getPlayerY() + i);
                        	for (Tile tile: currentTiles) {
	                        	if (testTiles.contains(tile)) {
	                        		playerCanMove = true;
	                        	}
                        	}
                        	if (playerCanMove && !checkMove(board.getPlayerX(), board.getPlayerY() + i, false)) {
                        		board.setPlayerY(board.getPlayerY() + i);
                        		playerMoved = true;
                        	}
                        	i++;
                        }
                    }
                    break;
                case LEFT:
                    if ((board.getPlayerY() - 1) <= -1 ||
                    		checkMove(board.getPlayerX(), board.getPlayerY() - 1, false)) {
                    } else {
                    	int i = 1;
                    	ArrayList<Tile> currentTiles = findCurrentTile(board.getPlayerX(), board.getPlayerY());
                        while (((board.getPlayerY() - i) >= -1 && playerMoved == false)) {
                        	boolean playerCanMove = false;
                        	ArrayList<Tile> testTiles = findCurrentTile(board.getPlayerX(), board.getPlayerY() - i);
                        	for (Tile tile: currentTiles) {
	                        	if (testTiles.contains(tile)) {
	                        		playerCanMove = true;
	                        	}
                        	}
                        	if (playerCanMove && !checkMove(board.getPlayerX(), board.getPlayerY() - i, false)) {
                        		board.setPlayerY(board.getPlayerY() - i);
                        		playerMoved = true;
                        	}
                        	i++;
                        }
                    }

                    break;
                case DOWN:
                    if ((board.getPlayerX() + 1) >= (width / 50.0 - 1 + 0.1)||
                    		checkMove(board.getPlayerX() + 1, board.getPlayerY(), false)) {
                    } else {
                    	int i = 1;
                    	ArrayList<Tile> currentTiles = findCurrentTile(board.getPlayerX(), board.getPlayerY());
                        while (((board.getPlayerX() + i) <= (width / 50.0 -1 + 0.1) && playerMoved == false)) {
                        	boolean playerCanMove = false;
                        	ArrayList<Tile> testTiles = findCurrentTile(board.getPlayerX() + i, board.getPlayerY());
                        	for (Tile tile: currentTiles) {
	                        	if (testTiles.contains(tile)) {
	                        		playerCanMove = true;
	                        	}
                        	}
                        	if (playerCanMove && !checkMove(board.getPlayerX() + i, board.getPlayerY(), false)) {
                        		board.setPlayerX(board.getPlayerX() + i);
                        		playerMoved = true;
                        	}
                        	i++;
                        }
                    }
                    break;
                case UP:
                    if ((board.getPlayerX() - 1) <= -1||
                    		checkMove(board.getPlayerX() - 1, board.getPlayerY(), false)) {
                    } else {
                    	int i = 1;
                    	ArrayList<Tile> currentTiles = findCurrentTile(board.getPlayerX(), board.getPlayerY());
                        while (((board.getPlayerX() - i) >= -1 && playerMoved == false)) {
                        	boolean playerCanMove = false;
                        	ArrayList<Tile> testTiles = findCurrentTile(board.getPlayerX() - i, board.getPlayerY());
                        	for (Tile tile: currentTiles) {
	                        	if (testTiles.contains(tile)) {
	                        		playerCanMove = true;
	                        	}
                        	}
                        	if (playerCanMove && !checkMove(board.getPlayerX() - i, board.getPlayerY(), false)) {
                        		board.setPlayerX(board.getPlayerX() - i);
                        		playerMoved = true;
                        	}
                        	i++;
                        }
                    }
                    break;
                case A:
                    if ((playerSpeed + 0.1) > 2.0) {

                    } else {
                        playerSpeed += 0.1;
                    }
                    break;
                case D:
                    if ((playerSpeed - 0.1) < 0.1) {

                    } else {
                        playerSpeed -= 0.1;
                    }
                    break;
                default:
                    // Do nothing for all other keys.
                    break;
            }
            System.out.println("Player: " + board.getPlayerX() + " " + board.getPlayerY());
            checkItemActivated();
        }
        findCurrentTile(board.getPlayerX(), board.getPlayerY());
        board.drawGame();
    }

    /**
     * See if the item is activated  by checking the position of the tiles to the characters.
     */
    public void checkItemActivated() {            
            ArrayList<Item> items = board.getItems();
            ArrayList<Item> removeItems = new ArrayList<>(); 
            ArrayList<Character> characters = board.getCharacters();
            ArrayList<String> charPositions = new ArrayList<>();
            
            for(Character character: characters) {
            	if (!(character instanceof FlyingAssassin)) {
            		charPositions.add(character.pos_x + "," + character.pos_y);
            	}
            }
            
            
            for(Item item: items){
                if(item.pos.getX() == player.pos_x && item.pos.getY() == player.pos_y) {
                	board.nowScore += item.score;
                }
                if ((item.pos.getX() == player.pos_x && item.pos.getY() == player.pos_y) || charPositions.contains((item.pos.getX() + "," + item.pos.getY()))) {
	                if (item instanceof GoldCoin || item instanceof SilverCoin || item instanceof Diamond) {
	                    collectableItems--;
	                    removeItems.add(item);
	                }
	                if (item instanceof Clock) {
	                	if (charPositions.contains((item.pos.getX() + "," + item.pos.getY()))) {
	                		board.setTime(board.getTime() - 10);
	                	} else {
	                		board.setTime(board.getTime() + 10);
	                	}
                     	removeItems.add(item);
                     }
	                if (item instanceof Lever) {
	                	removeItems.add(item);
	                	collectableItems--;
	                	for (Item checkGate: items) {
	                		if (checkGate instanceof Gate) {
	                			removeItems.add(checkGate);
	                		}
	                	}
	                }
	                if(item instanceof Door) {
	                	Door currentDoor = (Door) item;
	                	System.out.println("Items left:        " + collectableItems);
	                	if (currentDoor.getState() == true) {
	                        board.stopTickTimelineButton.setDisable(true);
	                        board.tickTimeline.stop();
	                        board.startTickTimelineButton.setDisable(false);
	                        board.continue_is = false;
	                        if (charPositions.contains((item.pos.getX() + "," + item.pos.getY()))) {
	                        	Alert alert = new Alert(Alert.AlertType.INFORMATION);
	                        	alert.setContentText("Failed! Thieves reached the door before you");
	                        	alert.show();
	                        }
	                        else if(nowLevel == 2){
	                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
	                            alert.setContentText("Congratulations!All Levels passed");
	                            alert.show();
	                            nowLevel = 1;
	                        }
	                        else {
	                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
	                            alert.setContentText("Congratulations! Next Level");
	                            alert.show();
	                            GameFrame.nowLevel += 1;

	                        }
	                	}
	                }
                }
            }
            for(Item item: removeItems){
                items.remove(item);
            }
            
            ArrayList<String> flyingAssassinsPos = new ArrayList<>();
            for (Character character: characters) {
            	if (character instanceof FlyingAssassin) {
            		flyingAssassinsPos.add(character.pos_x + "," + character.pos_y);
            	}
            }
            
            ArrayList<Character> removeCharacters = new ArrayList<>();            
            for (Character character: characters){
            	if (character instanceof FlyingAssassin) {
	                if(character.pos_x == player.pos_x && character.pos_y == player.pos_y) {
	                    board.stopTickTimelineButton.setDisable(true);
	                    board.tickTimeline.stop();
	                    board.startTickTimelineButton.setDisable(false);
	                    board.continue_is = false;
	                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
	                    alert.setContentText("The Flying Assassin attacked you.\nFailed!");
	                    alert.show();
	                }
            	}
            	if (!(character instanceof FlyingAssassin)) {
            		if (flyingAssassinsPos.contains((character.pos_x + "," + character.pos_y))) {
	                	removeCharacters.add(character);
            		}
            	}
            }
            
            for (Character character: removeCharacters) {
            	characters.remove(character);
            }
        }
        // Redraw game as the player may have moved.
    
    public boolean checkMove(float x, float y, boolean isNPC){
        ArrayList<Item> items = board.getItems();
        for(Item item: items){
            if(item instanceof Door){
            	Door currentDoor = (Door) item;
            	if (collectableItems == 0) {
            		currentDoor.openDoor();
                }
                if(x == item.pos.getX() && y == item.pos.getY() && currentDoor.getState() == false){
                    return true;
                }
            } else if (item instanceof Gate) {
            	if(x == item.pos.getX() && y == item.pos.getY()){
                    return true;
                }
            }
        }
        ArrayList<Character> characters = board.getCharacters();
        for(Character character: characters){
            if(character instanceof FloorFollowingThief || character instanceof SmartThief){
                if(x == character.pos_x && y == character.pos_y){
                    return true;
                }
            }
        }
        
        if(isNPC && x == player.pos_x && y == player.pos_y) {
        	return true;
        }
        
        return false;
    }
    
    public ArrayList<Tile> findCurrentTile(float x, float y) {
    	ArrayList<ArrayList<Tile>> tilePositions = board.getBoardTiles();
    	ArrayList<Tile> tileColours = new ArrayList<>();
    	Tile topLeftTile = tilePositions.get((int) x*2).get((int) (y*2));
    	Tile topRightTile = tilePositions.get((int) x*2).get((int) (y*2)+1);
    	Tile bottomLeftTile = tilePositions.get((int) (x*2)+1).get((int) y*2);
    	Tile bottomRightTile = tilePositions.get((int) (x*2)+1).get((int) (y*2)+1);
		tileColours.add(topLeftTile);
		tileColours.add(topRightTile);
		tileColours.add(bottomLeftTile);
		tileColours.add(bottomRightTile);
    	return tileColours;
    }

    public static int getNowLevel() {
        return nowLevel;
    }

    public void setNowLevel(int nowLevel) {
        this.nowLevel = nowLevel;
    }

    public static Player getPlayer() {
        return player;
    }

    public ArrayList<Item> getItems() {
        return items;
    }

    public ArrayList<Character> getCharacters() {
        return characters;
    }
}
