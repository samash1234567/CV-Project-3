/**
 * NPC Class
 * @version 1.0
 * @author Group Juan
 */
public class NPC extends Character{
    String entity;
    float entitySpeed;

    /**
     * Creates an NPC
     * @param objectName NPC objectname
     * @param x Position on the board
     * @param y Position on the Board
     */
    public NPC(String objectName, int x, int y) {
        super(objectName, x, y);
    }

    /**
     * Creates a new NPC Entity
     * @param entity Entity name
     * @param entitySpeed Speed of the entity
     * @param objectName Name of the object
     * @param x Position on the board
     * @param y Position on the board
     */
    public NPC(String entity, float entitySpeed, String objectName, int x, int y) {
        super(objectName, x, y);
        this.entity = entity;
        this.entitySpeed = entitySpeed;
    }

    public Position getNPCPos(){
        return new Position(pos_x, pos_y);
    }

    public void setNPCPos(int x, int y){
        pos_x = x;
        pos_y = y;
    }
}
