
import javafx.scene.image.Image;

/**
 * Bomb Class
 * @version 1.0
 * @author Group Juan
 */
public class Bomb extends Item{

    /**
     *
     */
    private boolean state;
    int blastRadius;
    int countDownTime;

    /**
     * Constructor to create a bomb.
     * @param image Process the image of the bomb
     * @param pos Process the position of the bomb
     */
    public Bomb(Image image, Position pos) {
        super(image, pos, "Bomb");
    }

    public void setState(){

    }

    public void detonate(){

    }

    public void countDown(){

    }
}
