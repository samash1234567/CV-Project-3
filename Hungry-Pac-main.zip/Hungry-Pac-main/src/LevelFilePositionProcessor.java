import java.io.FileNotFoundException;
import java.util.ArrayList;

import javafx.scene.image.Image;

/**
 * LevelFileProcessor Class
 * @version 1.0
 * @author Group Juan
 */
class LevelFilePositionProcessor {
     Board board;
     Player player;
     private int nowLevel;
     private TxtFileProcessor Level1File;
     private TxtFileProcessor Level2File;
     private TxtFileProcessor CustomLevel;
     ArrayList<Item> items;
     ArrayList<Character> characters;
     int collectableItems;

    /**
     * Create a new level file processor.
     * @param board Process the board
     * @param player Process the player
     * @param nowLevel Process the level
     */
    public LevelFilePositionProcessor(Board board, Player player, int nowLevel) {
         this.board = board;
         this.player = player;
         this.nowLevel = nowLevel;
     }

    /**
     * Load the positions of all the characters,items, and levels.
     * @throws FileNotFoundException
     */
     public void loadPositions() throws FileNotFoundException {
         Level1File = new TxtFileProcessor("resources/Level1Positions.txt");
         Level2File = new TxtFileProcessor("resources/Level2Positions.txt");
         CustomLevel = new TxtFileProcessor("resources/PlayerPositions.txt");
         ArrayList<String> res1 = new ArrayList<>();
         if(nowLevel == 1){
             res1 = Level1File.readFromFile();
         }
         else if(nowLevel == 2){
             res1 = Level2File.readFromFile();
         }
         else if(nowLevel == 3){
             res1 = CustomLevel.readFromFile();
         }
         else{
             res1 = null;
         }
         items = new ArrayList<>();
         characters = new ArrayList<>();
         int nowLevel = 1;
         for(int i = 0; res1 != null && i < res1.size(); i++){
             String[] res2 = res1.get(i).split(";");
             for(int j = 0; j < res2.length; j++){
                 String temp = res2[j];
                 if(temp.equals("Player")){
                	 player = new Player("Player", "Player" + nowLevel, i, j);
                 }
				 else if(temp.equals("GoldCoin")){
				     items.add(new GoldCoin(board.goldCoin, i, j));
				     collectableItems++;
				 }
				 else if(temp.equals("SilverCoin")){
					 items.add(new GoldCoin(board.silverCoin, i, j));
				     collectableItems++;
				 }
				 else if(temp.equals("Diamond")){
				     items.add(new Diamond(board.diamond, i, j));
				     collectableItems++;
				 }
				 else if(temp.equals("Door")){
				     items.add(new Door(board.doorImage, i, j));
				 }
				 // add lever
				 else if(temp.equals("LeverOne")) {
					 items.add(new Lever(board.leverOneImage, i, j));
					 collectableItems++;
				 }
				 else if(temp.equals("LeverTwo")) {
					 items.add(new Lever(board.leverTwoImage, i, j));
					 collectableItems++;
				 }
				 else if(temp.equals("gateOne")){
				     items.add(new Gate(board.gate1Image, i, j, false));
				 }
				 else if(temp.equals("gateTwo")){
				     items.add(new Gate(board.gate2Image, i, j, false));
				 }
				 else if(temp.equals("Clock")) {
					 items.add(new Clock(board.clock, i, j));
				 }
				 else if(temp.equals("SmartThief")){
					 characters.add(new SmartThief(board.smartThief, "SmartThief", 0.5F, "SmartThief", i, j));
				 }
				 else if(temp.equals("FlyingAssassin")){
					 characters.add(new FlyingAssassin(board.flyingAssassin, "FlyingAssassin",  i, j));
				 }
				 else if(temp.equals("FloorFollowingThief")){
					 TileType tileT = new TileType();
					 tileT.addTile("B", new Image("file:resources/blueTile.png"));
				     tileT.addTile("G", new Image("file:resources/greenTile.png"));
				     tileT.addTile("M", new Image("file:resources/magentaTile.png"));
				     tileT.addTile("R", new Image("file:resources/redTile.png"));
				     tileT.addTile("Y", new Image("file:resources/yellowTile.png"));
				     tileT.addTile("C", new Image("file:resources/cyanTile.png"));
					 Tile tile = tileT.getTile("R");
					 characters.add(new FloorFollowingThief(tile, board.floorFollowingThief, "FloorFollowingThief",  1.2F, "FloorFollowingThief", i, j));
				 }
             }
         }
         board.setPlayer(player);
         board.setItems(items);
         board.setCharacters(characters);
         board.setTime(board.timeVal);
     }

     public Board getBoard() {
         return board;
     }

     public Player getPlayer() {
         return player;
     }

     public int getNowLevel() {
         return nowLevel;
     }
 }
