import java.io.*;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;
import java.util.stream.*;

/**
 * TextFileProcessor Class
 * @version 1.0
 * @author Group Juan
 */
public class TxtFileProcessor {
    protected Scanner fileScanner; // used to read from file
    protected PrintWriter writer; // used to write to file
    protected String path; // stored file path
    protected String fileName;
    protected File file; // file to be written and read from
    protected ArrayList<String> lines;

    /**
     * Create a new processor for the file and read it.
     * @param fileName Specify the files name to be processed
     * @throws FileNotFoundException
     */
    protected TxtFileProcessor(String fileName) throws FileNotFoundException {
        FileReader fr = new FileReader(fileName);
        if (fr == null) {
            throw new IllegalArgumentException("Error, file not found!");
        } else {
            BufferedReader br = new BufferedReader(fr);
            Stream<String> linesBR = br.lines();
            this.lines = getArrayListFromStream(linesBR);
        }
    }

    public static <T> ArrayList<T> getArrayListFromStream(Stream<T> stream) {
        List<T>
                list = stream.collect(Collectors.toList());

        ArrayList<T>
                arrayList = new ArrayList<T>(list);
        System.out.println("ArrayList: " + arrayList);
        return arrayList;
    }
    public ArrayList<String> readFromFile() {
        return lines;
    }
}
